"use client"

import { useState, useEffect, useRef } from "react"
import { motion } from "framer-motion"
import { Download, Pause, Play, RotateCcw } from "lucide-react"

export default function TextToSpeech() {
  const [text, setText] = useState("")
  const [rate, setRate] = useState(1)
  const [pitch, setPitch] = useState(1)
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [isPaused, setIsPaused] = useState(false)
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null)
  const synth = useRef<SpeechSynthesis | null>(null)
  const mediaRecorderRef = useRef<MediaRecorder | null>(null)
  const audioChunksRef = useRef<Blob[]>([])

  useEffect(() => {
    synth.current = window.speechSynthesis
    return () => {
      if (synth.current?.speaking) {
        synth.current.cancel()
      }
    }
  }, [])

  const handleSpeak = () => {
    if (synth.current?.speaking) {
      if (isPaused) {
        synth.current.resume()
        setIsPaused(false)
      } else {
        synth.current.pause()
        setIsPaused(true)
      }
      return
    }

    if (text) {
      const utterance = new SpeechSynthesisUtterance(text)
      utterance.rate = rate
      utterance.pitch = pitch

      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()
      const mediaStreamDestination = audioContext.createMediaStreamDestination()
      mediaRecorderRef.current = new MediaRecorder(mediaStreamDestination.stream)
      audioChunksRef.current = []

      mediaRecorderRef.current.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data)
      }

      mediaRecorderRef.current.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: "audio/wav" })
        setAudioBlob(audioBlob)
      }

      mediaRecorderRef.current.start()

      utterance.onstart = () => setIsSpeaking(true)
      utterance.onend = () => {
        setIsSpeaking(false)
        setIsPaused(false)
        if (mediaRecorderRef.current && mediaRecorderRef.current.state !== "inactive") {
          mediaRecorderRef.current.stop()
        }
      }
      utterance.onpause = () => setIsPaused(true)
      utterance.onresume = () => setIsPaused(false)

      synth.current?.speak(utterance)
    }
  }

  const handleStop = () => {
    if (synth.current?.speaking) {
      synth.current.cancel()
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== "inactive") {
      mediaRecorderRef.current.stop()
    }
    setIsSpeaking(false)
    setIsPaused(false)
  }

  const handleDownload = () => {
    if (audioBlob) {
      const url = URL.createObjectURL(audioBlob)
      const a = document.createElement("a")
      a.href = url
      a.download = "speech.wav"
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
    }
  }

  return (
    <div className="space-y-6 p-4 max-w-md mx-auto">
      <h2 className="text-2xl font-bold text-center">Text to Speech</h2>

      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Enter your text here..."
        className="w-full h-32 p-4 bg-secondary/50 rounded-xl resize-none focus:outline-none focus:ring-2 focus:ring-primary text-base"
      />

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-2">Speed: {rate.toFixed(1)}</label>
          <input
            type="range"
            min="0.5"
            max="2"
            step="0.1"
            value={rate}
            onChange={(e) => setRate(Number(e.target.value))}
            className="w-full h-2 bg-secondary rounded-lg appearance-none cursor-pointer accent-primary"
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">Pitch: {pitch.toFixed(1)}</label>
          <input
            type="range"
            min="0.5"
            max="2"
            step="0.1"
            value={pitch}
            onChange={(e) => setPitch(Number(e.target.value))}
            className="w-full h-2 bg-secondary rounded-lg appearance-none cursor-pointer accent-primary"
          />
        </div>
      </div>

      <div className="flex justify-center space-x-4">
        <button
          onClick={handleSpeak}
          disabled={!text}
          className="py-2 px-4 bg-primary text-primary-foreground font-semibold rounded-lg 
                    hover:bg-primary/90 transition duration-300 ease-in-out transform hover:scale-105
                    disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
        >
          {isSpeaking ? isPaused ? <Play size={20} /> : <Pause size={20} /> : <Play size={20} />}
          {isSpeaking ? (isPaused ? "Resume" : "Pause") : "Speak"}
        </button>
        <button
          onClick={handleStop}
          disabled={!isSpeaking}
          className="py-2 px-4 bg-destructive text-destructive-foreground font-semibold rounded-lg 
                    hover:bg-destructive/90 transition duration-300 ease-in-out transform hover:scale-105
                    disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
        >
          <RotateCcw size={20} />
          Stop
        </button>
        <button
          onClick={handleDownload}
          disabled={!audioBlob}
          className="py-2 px-4 bg-accent text-accent-foreground font-semibold rounded-lg 
                    hover:bg-accent/80 transition duration-300 ease-in-out transform hover:scale-105
                    disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
        >
          <Download size={20} />
          Download
        </button>
      </div>

      {isSpeaking && (
        <motion.div
          className="flex justify-center space-x-1"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          {[...Array(5)].map((_, i) => (
            <motion.div
              key={i}
              className="w-1 h-6 bg-primary rounded-full"
              animate={{
                height: ["24px", "12px", "24px"],
              }}
              transition={{
                duration: 0.5,
                repeat: Number.POSITIVE_INFINITY,
                repeatType: "reverse",
                delay: i * 0.1,
              }}
            />
          ))}
        </motion.div>
      )}
    </div>
  )
}

