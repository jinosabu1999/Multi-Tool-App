"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Activity, MessageSquare, Timer } from "lucide-react"
import BMICalculator from "./BMICalculator"
import TextToSpeech from "./TextToSpeech"
import CountdownTimer from "./CountdownTimer"

const tools = [
  { id: "bmi", name: "Health", icon: Activity, component: BMICalculator },
  { id: "tts", name: "Speech", icon: MessageSquare, component: TextToSpeech },
  { id: "timer", name: "Timer", icon: Timer, component: CountdownTimer },
]

export default function ToolSelector() {
  const [selectedTool, setSelectedTool] = useState(tools[0])

  return (
    <div className="relative min-h-screen w-full bg-gradient-to-b from-background via-background/95 to-background">
      <div className="fixed inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5 pointer-events-none" />

      <div className="relative pb-20 pt-4">
        <div className="px-4 mx-auto max-w-md">
          <AnimatePresence mode="wait">
            <motion.div
              key={selectedTool.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{
                duration: 0.2,
                type: "spring",
                stiffness: 300,
                damping: 25,
              }}
              className="rounded-2xl glass-card overflow-hidden"
            >
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-accent/10 opacity-50" />
                <div className="relative">
                  <selectedTool.component />
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      <nav className="fixed bottom-0 left-0 right-0 glass-effect safe-area-bottom">
        <div className="max-w-md mx-auto">
          <div className="flex justify-around items-center h-16">
            {tools.map((tool) => {
              const Icon = tool.icon
              const isSelected = selectedTool.id === tool.id
              return (
                <motion.button
                  key={tool.id}
                  onClick={() => setSelectedTool(tool)}
                  className="relative w-full h-full touch-none"
                  whileTap={{ scale: 0.95 }}
                >
                  <div className="flex flex-col items-center justify-center py-2 space-y-1">
                    <motion.div
                      animate={
                        isSelected
                          ? {
                              scale: [1, 1.2, 1],
                              transition: { duration: 0.3 },
                            }
                          : {}
                      }
                    >
                      <Icon
                        size={24}
                        className={`transition-colors duration-200 ${
                          isSelected ? "text-primary neon-glow" : "text-muted-foreground"
                        }`}
                      />
                    </motion.div>
                    <span
                      className={`text-xs transition-colors duration-200 ${
                        isSelected ? "text-primary font-medium" : "text-muted-foreground"
                      }`}
                    >
                      {tool.name}
                    </span>
                  </div>
                  {isSelected && (
                    <motion.div
                      layoutId="activeTab"
                      className="absolute bottom-0 left-[10%] right-[10%] h-0.5 bg-gradient-to-r from-primary via-primary to-accent rounded-full"
                      initial={false}
                      transition={{
                        type: "spring",
                        stiffness: 500,
                        damping: 30,
                      }}
                    />
                  )}
                </motion.button>
              )
            })}
          </div>
        </div>
      </nav>
    </div>
  )
}

