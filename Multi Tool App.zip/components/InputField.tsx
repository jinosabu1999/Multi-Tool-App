import type { ChangeEvent } from "react"

interface InputFieldProps {
  label: string
  value: string
  onChange: (value: string) => void
}

export default function InputField({ label, value, onChange }: InputFieldProps) {
  return (
    <div className="flex flex-col space-y-1">
      <label className="text-sm md:text-base text-gray-700 dark:text-gray-300">{label}</label>
      <input
        type="number"
        value={value}
        onChange={(e: ChangeEvent<HTMLInputElement>) => onChange(e.target.value)}
        className="w-full bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-white rounded-lg px-3 py-2 text-sm md:text-base focus:outline-none focus:ring-2 focus:ring-blue-500"
        min="0"
        step="any"
      />
    </div>
  )
}

