"use client"

import { useState, useEffect, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Play, Pause, RotateCcw, Volume2, VolumeX, Vibrate, Plus, Edit2, Check, X } from "lucide-react"

interface Timer {
  id: string
  hours: number
  minutes: number
  seconds: number
  totalTime: number
  initialTime: number
  isPaused: boolean
  isFinished: boolean
  name?: string
  isEditing?: boolean
}

interface Preset {
  id: string
  name: string
  duration: number
}

const DEFAULT_PRESETS: Preset[] = [
  { id: "pomodoro", name: "Pomodoro", duration: 1500 },
  { id: "break", name: "Break", duration: 300 },
  { id: "exercise", name: "Exercise", duration: 1800 },
]

export default function CountdownTimer() {
  const [timers, setTimers] = useState<Timer[]>([])
  const [soundEnabled, setSoundEnabled] = useState(true)
  const [vibrationEnabled, setVibrationEnabled] = useState(true)
  const [presets] = useState<Preset[]>(DEFAULT_PRESETS)
  const [selectedPreset, setSelectedPreset] = useState<string | null>(null)

  const intervalRefs = useRef<{ [key: string]: NodeJS.Timeout }>({})
  const alarmRef = useRef<HTMLAudioElement | null>(null)

  useEffect(() => {
    if (timers.length === 0) {
      createTimer(1500, "Pomodoro")
    }
  }, [timers.length])

  useEffect(() => {
    alarmRef.current = new Audio("https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3")
    return () => {
      Object.values(intervalRefs.current).forEach(clearInterval)
    }
  }, [])

  const createTimer = (duration = 0, name?: string) => {
    const hours = Math.floor(duration / 3600)
    const minutes = Math.floor((duration % 3600) / 60)
    const seconds = duration % 60

    const newTimer: Timer = {
      id: Date.now().toString(),
      hours,
      minutes,
      seconds,
      totalTime: duration,
      initialTime: duration,
      isPaused: true,
      isFinished: false,
      name,
      isEditing: false,
    }
    setTimers((prev) => [...prev, newTimer])
    setSelectedPreset(name || null)
  }

  const startTimer = (id: string) => {
    setTimers((prev) =>
      prev.map((timer) => (timer.id === id ? { ...timer, isPaused: false, isEditing: false } : timer)),
    )

    intervalRefs.current[id] = setInterval(() => {
      setTimers((prev) => {
        const timerIndex = prev.findIndex((t) => t.id === id)
        if (timerIndex === -1) return prev

        const timer = prev[timerIndex]
        if (timer.totalTime <= 1) {
          clearInterval(intervalRefs.current[id])
          if (soundEnabled) playAlarm()
          if (vibrationEnabled) {
            try {
              window.navigator.vibrate([200, 100, 200])
            } catch (error) {
              console.error("Vibration API not supported")
            }
          }

          const newTimers = [...prev]
          newTimers[timerIndex] = { ...timer, totalTime: 0, isFinished: true, isPaused: true }
          return newTimers
        }

        const newTimers = [...prev]
        newTimers[timerIndex] = { ...timer, totalTime: timer.totalTime - 1 }
        return newTimers
      })
    }, 1000)
  }

  const pauseTimer = (id: string) => {
    clearInterval(intervalRefs.current[id])
    setTimers((prev) => prev.map((timer) => (timer.id === id ? { ...timer, isPaused: true } : timer)))
  }

  const resetTimer = (id: string) => {
    clearInterval(intervalRefs.current[id])
    setTimers((prev) =>
      prev.map((timer) =>
        timer.id === id
          ? {
              ...timer,
              totalTime: timer.initialTime,
              isPaused: true,
              isFinished: false,
              isEditing: false,
            }
          : timer,
      ),
    )
  }

  const toggleEdit = (id: string) => {
    setTimers((prev) => prev.map((timer) => (timer.id === id ? { ...timer, isEditing: !timer.isEditing } : timer)))
  }

  const updateTimer = (id: string, hours: number, minutes: number, seconds: number) => {
    const totalTime = hours * 3600 + minutes * 60 + seconds
    setTimers((prev) =>
      prev.map((timer) =>
        timer.id === id
          ? {
              ...timer,
              hours,
              minutes,
              seconds,
              totalTime,
              initialTime: totalTime,
              isEditing: false,
              isPaused: true,
              isFinished: false,
            }
          : timer,
      ),
    )
  }

  const playAlarm = () => {
    if (alarmRef.current) {
      alarmRef.current.play()
    }
  }

  const stopAlarm = () => {
    if (alarmRef.current) {
      alarmRef.current.pause()
      alarmRef.current.currentTime = 0
    }
  }

  const formatTime = (time: number) => {
    const hours = Math.floor(time / 3600)
    const minutes = Math.floor((time % 3600) / 60)
    const seconds = time % 60
    return `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`
  }

  return (
    <div className="space-y-6 p-4">
      <div className="flex items-center justify-between mb-6">
        <div className="flex space-x-2">
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className={`p-3 rounded-full transition-colors ${
              soundEnabled ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground"
            }`}
          >
            {soundEnabled ? <Volume2 size={20} /> : <VolumeX size={20} />}
          </button>
          <button
            onClick={() => setVibrationEnabled(!vibrationEnabled)}
            className={`p-3 rounded-full transition-colors ${
              vibrationEnabled ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground"
            }`}
          >
            <Vibrate size={20} />
          </button>
        </div>
        <button
          onClick={() => createTimer()}
          className="p-3 rounded-full bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
        >
          <Plus size={20} />
        </button>
      </div>

      <div className="flex overflow-x-auto gap-2 pb-2 -mx-4 px-4">
        {presets.map((preset) => (
          <button
            key={preset.id}
            onClick={() => createTimer(preset.duration, preset.name)}
            className={`px-4 py-2 rounded-full transition-colors ${
              selectedPreset === preset.name
                ? "bg-primary text-primary-foreground"
                : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
            }`}
          >
            {preset.name}
          </button>
        ))}
      </div>

      <div className="space-y-4">
        <AnimatePresence>
          {timers.map((timer) => (
            <motion.div
              key={timer.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, x: -100 }}
              className="relative p-6 rounded-2xl border bg-card"
            >
              {timer.name && (
                <div className="absolute top-4 left-4 text-sm font-medium text-muted-foreground">{timer.name}</div>
              )}
              <div className="relative aspect-square max-w-[200px] mx-auto">
                {timer.isEditing ? (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="grid grid-cols-3 gap-2">
                      <input
                        type="number"
                        value={timer.hours}
                        onChange={(e) => {
                          const value = Math.max(0, Math.min(99, Number.parseInt(e.target.value) || 0))
                          updateTimer(timer.id, value, timer.minutes, timer.seconds)
                        }}
                        className="w-16 p-2 text-center bg-secondary rounded"
                        placeholder="HH"
                        min="0"
                        max="99"
                      />
                      <input
                        type="number"
                        value={timer.minutes}
                        onChange={(e) => {
                          const value = Math.max(0, Math.min(59, Number.parseInt(e.target.value) || 0))
                          updateTimer(timer.id, timer.hours, value, timer.seconds)
                        }}
                        className="w-16 p-2 text-center bg-secondary rounded"
                        placeholder="MM"
                        min="0"
                        max="59"
                      />
                      <input
                        type="number"
                        value={timer.seconds}
                        onChange={(e) => {
                          const value = Math.max(0, Math.min(59, Number.parseInt(e.target.value) || 0))
                          updateTimer(timer.id, timer.hours, timer.minutes, value)
                        }}
                        className="w-16 p-2 text-center bg-secondary rounded"
                        placeholder="SS"
                        min="0"
                        max="59"
                      />
                    </div>
                  </div>
                ) : (
                  <>
                    <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                      <circle
                        cx="50"
                        cy="50"
                        r="45"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        className="text-secondary"
                      />
                      <circle
                        cx="50"
                        cy="50"
                        r="45"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeDasharray={`${(timer.totalTime / timer.initialTime) * 283} 283`}
                        className="text-primary transition-all duration-1000"
                      />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-2xl md:text-3xl font-bold tabular-nums">{formatTime(timer.totalTime)}</span>
                    </div>
                  </>
                )}
              </div>
              <div className="flex justify-center gap-2 mt-4">
                {timer.isEditing ? (
                  <>
                    <button
                      onClick={() => toggleEdit(timer.id)}
                      className="p-3 rounded-full bg-destructive text-destructive-foreground hover:bg-destructive/90 transition-colors"
                    >
                      <X size={20} />
                    </button>
                    <button
                      onClick={() => toggleEdit(timer.id)}
                      className="p-3 rounded-full bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
                    >
                      <Check size={20} />
                    </button>
                  </>
                ) : (
                  <>
                    <button
                      onClick={() => (timer.isPaused ? startTimer(timer.id) : pauseTimer(timer.id))}
                      className="p-3 rounded-full bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
                      disabled={timer.isFinished}
                    >
                      {timer.isPaused ? <Play size={20} /> : <Pause size={20} />}
                    </button>
                    <button
                      onClick={() => resetTimer(timer.id)}
                      className="p-3 rounded-full bg-secondary text-secondary-foreground hover:bg-secondary/80 transition-colors"
                    >
                      <RotateCcw size={20} />
                    </button>
                    <button
                      onClick={() => toggleEdit(timer.id)}
                      className="p-3 rounded-full bg-secondary text-secondary-foreground hover:bg-secondary/80 transition-colors"
                    >
                      <Edit2 size={20} />
                    </button>
                  </>
                )}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  )
}

