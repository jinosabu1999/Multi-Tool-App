import { ThemeSwitcher } from "../components/ThemeSwitcher"
import ToolSelector from "../components/ToolSelector"

export default function Home() {
  return (
    <main className="min-h-screen bg-background text-foreground overflow-hidden">
      {/* Decorative gradient orbs */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-[40vh] -left-[20vw] w-[80vw] h-[80vh] bg-primary/10 rounded-full blur-3xl" />
        <div className="absolute -bottom-[40vh] -right-[20vw] w-[80vw] h-[80vh] bg-accent/10 rounded-full blur-3xl" />
      </div>

      {/* Content */}
      <div className="relative">
        <ThemeSwitcher />
        <ToolSelector />
      </div>
    </main>
  )
}

